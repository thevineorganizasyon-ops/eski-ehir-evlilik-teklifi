/* Eskişehir Evlilik Teklifi — küçük, bağımsız betik (kütüphane yok) */
(function () {
  "use strict";
  var WA = document.documentElement.getAttribute("data-wa") || "905321531726";
  window.dataLayer = window.dataLayer || [];
  function olay(ad, veri) { var o = { event: ad }; for (var k in veri) o[k] = veri[k]; window.dataLayer.push(o); }

  // Mobil menü
  var ac = document.querySelector(".menu-ac"), menu = document.getElementById("menu");
  if (ac && menu) ac.addEventListener("click", function () {
    var acik = menu.classList.toggle("acik");
    ac.setAttribute("aria-expanded", acik ? "true" : "false");
  });

  // Üst menü: sayfa kaydırılınca koyu zemine geç
  var ust = document.getElementById("ust");
  if (ust) {
    var kaydir = function () { ust.classList.toggle("dolu", window.scrollY > 40 || (menu && menu.classList.contains("acik"))); };
    window.addEventListener("scroll", kaydir, { passive: true }); kaydir();
    if (ac) ac.addEventListener("click", kaydir);
  }

  // WhatsApp ve telefon tıklamalarını ölç (GTM / GA4 dönüşümleri için)
  document.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest("a") : null;
    if (!a) return;
    var h = a.getAttribute("href") || "";
    if (h.indexOf("wa.me/") > -1) olay("whatsapp_tikla", { konum: a.getAttribute("data-konum") || "genel", sayfa: location.pathname });
    else if (h.indexOf("tel:") === 0) olay("telefon_tikla", { konum: a.getAttribute("data-konum") || "genel", sayfa: location.pathname });
  });

  // Konsepte göre fiyat teklifi formu → hazır WhatsApp mesajı
  var formlar = document.querySelectorAll("form[data-teklif]");
  Array.prototype.forEach.call(formlar, function (f) {
    try {
      var p = new URLSearchParams(location.search).get("konsept");
      if (p) { var r = f.querySelector('input[name="konsept"][value="' + p + '"]'); if (r) r.checked = true; }
    } catch (err) {}
    f.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = function (ad) { var el = f.elements[ad]; return el ? (el.value || "").trim() : ""; };
      var secili = f.querySelector('input[name="konsept"]:checked');
      var konsept = secili ? secili.getAttribute("data-ad") : "Henüz karar vermedim";
      var ekstra = Array.prototype.map.call(f.querySelectorAll('input[name="ekstra"]:checked'), function (x) { return x.value; });
      var tarih = v("tarih");
      if (tarih && /^\d{4}-\d{2}-\d{2}$/.test(tarih)) { var t = tarih.split("-"); tarih = t[2] + "." + t[1] + "." + t[0]; }
      var satirlar = [
        "Merhaba, evlilik teklifi için fiyat teklifi almak istiyorum.",
        "",
        "- Konsept: " + konsept,
        "- Şehir / ilçe: " + (v("sehir") || "Belirtilmedi"),
        "- Tarih: " + (tarih || "Esnek") + (v("saat") ? " (" + v("saat") + ")" : ""),
        "- Eklemek istediklerim: " + (ekstra.length ? ekstra.join(", ") : "Önerilerinize açığım")
      ];
      if (v("ad")) satirlar.push("- Adım: " + v("ad"));
      if (v("telefon")) satirlar.push("- Telefon: " + v("telefon"));
      if (v("not")) satirlar.push("- Not: " + v("not"));
      var url = "https://wa.me/" + WA + "?text=" + encodeURIComponent(satirlar.join("\n"));
      olay("teklif_formu_gonder", { konsept: konsept, sehir: v("sehir") || "belirtilmedi", ekstra_sayisi: ekstra.length });
      var sonuc = f.querySelector(".form-sonuc");
      if (sonuc) {
        sonuc.innerHTML = 'Mesajınız hazır. WhatsApp açılmadıysa <a href="' + url + '" target="_blank" rel="noopener">buraya dokunarak gönderin</a>.';
        sonuc.classList.add("acik");
      }
      var w = null;
      try { w = window.open(url, "_blank", "noopener"); } catch (err) {}
      if (!w) { try { location.href = url; } catch (err) {} }
    });
  });

  // Sessiz kısa videolar görünür olunca oynasın
  var oto = document.querySelectorAll("video[data-oto]");
  if (oto.length && "IntersectionObserver" in window && !(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches)) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { var v = e.target; if (e.isIntersecting) { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); } else v.pause(); });
    }, { threshold: 0.35 });
    Array.prototype.forEach.call(oto, function (v) { io.observe(v); });
  }

  var azHareket = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Ara bant: kaydırdıkça hafif hareket
  var paralaks = document.querySelectorAll("[data-paralaks]");
  if (paralaks.length && !azHareket) {
    var bekliyor = false;
    var guncelle = function () {
      bekliyor = false;
      Array.prototype.forEach.call(paralaks, function (el) {
        var r = el.parentNode.getBoundingClientRect();
        if (r.bottom < 0 || r.top > window.innerHeight) return;
        var oran = (r.top + r.height / 2 - window.innerHeight / 2) / window.innerHeight;
        el.style.transform = "translate3d(0," + (oran * -90).toFixed(1) + "px,0)";
      });
    };
    window.addEventListener("scroll", function () { if (!bekliyor) { bekliyor = true; requestAnimationFrame(guncelle); } }, { passive: true });
    guncelle();
  }

  // Galeri ışık kutusu
  var kutu = document.querySelector("dialog.isik-kutu");
  if (kutu && kutu.showModal) {
    var kimg = kutu.querySelector("img");
    document.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-buyuk]") : null;
      if (!b) return;
      kimg.src = b.getAttribute("data-buyuk"); kimg.alt = b.getAttribute("data-alt") || "";
      kutu.showModal(); olay("galeri_ac", { gorsel: b.getAttribute("data-buyuk") });
    });
    kutu.addEventListener("click", function (e) { if (e.target === kutu || e.target.tagName === "BUTTON") kutu.close(); });
  }

  // Çerez onayı (Google Consent Mode v2)
  var cerez = document.querySelector(".cerez");
  var kayit = null; try { kayit = localStorage.getItem("cerez"); } catch (err) {}
  if (cerez && !kayit) cerez.classList.add("acik");
  function karar(k) {
    try { localStorage.setItem("cerez", k); } catch (err) {}
    if (typeof window.gtag === "function") {
      var d = k === "kabul" ? "granted" : "denied";
      window.gtag("consent", "update", { ad_storage: d, analytics_storage: d, ad_user_data: d, ad_personalization: d });
    }
    olay("cerez_karar", { karar: k });
    if (cerez) cerez.classList.remove("acik");
  }
  if (cerez) {
    var kb = cerez.querySelector("[data-cerez=kabul]"), rd = cerez.querySelector("[data-cerez=red]");
    if (kb) kb.addEventListener("click", function () { karar("kabul"); });
    if (rd) rd.addEventListener("click", function () { karar("red"); });
  }
})();
